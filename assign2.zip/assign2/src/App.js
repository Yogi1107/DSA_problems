import React, { useState } from "react";
import ProgressBar from "./ProgressBar";

function App() {
  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [email, setEmail] = useState("");
  const [progress, setProgress] = useState(40);

  const [errors, setErrors] = useState({});

  const validate = () => {
    let newErrors = {};

    if (!name.trim()) {
      newErrors.name = "Name is required";
    } else if (name.trim().length < 2) {
      newErrors.name = "Name must be at least 2 characters";
    } else if (/^\s/.test(name)) {
      newErrors.name = "Name should not start with a space";
    } else if (!/^[A-Za-z\s]+$/.test(name.trim())) {
      newErrors.name = "Name should contain only letters";
    }

    const ageNum = Number(age);

    if (!age) {
      newErrors.age = "Age is required";
    } else if (isNaN(ageNum)) {
      newErrors.age = "Age must be a number";
    } else if (ageNum <= 0 || ageNum > 120) {
      newErrors.age = "Age must be between 1 and 120";
    }

    if (!email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = "Invalid email format";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (validate()) {
      alert("Form submitted successfully!");
      console.log({
        name: name.trim(),
        age: Number(age),
        email: email.trim(),
      });
    }
  };

  return (
    <div>
      <h3>Assignment 2, Question 1</h3>
      <h2>User Form</h2>

      <form onSubmit={handleSubmit}>
        {/* Name */}
        <div>
          <label>Name: </label>
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          {errors.name && <p style={{ color: "red" }}>{errors.name}</p>}
        </div>

        {/* Age */}
        <div>
          <label>Age: </label>
          <input
            type="text"
            value={age}
            onChange={(e) => setAge(e.target.value)}
          />
          {errors.age && <p style={{ color: "red" }}>{errors.age}</p>}
        </div>

        {/* Email */}
        <div>
          <label>Email: </label>
          <input
            type="text"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          {errors.email && <p style={{ color: "red" }}>{errors.email}</p>}
        </div>

        <button type="submit">Submit</button>
      </form>

      <br />

      <h3>Assignment 2, Question 2</h3>
      <h2>Progress Bar</h2>

      <ProgressBar progress={progress} />

      <button onClick={() => setProgress(Math.min(progress + 10, 100))}>
        Increase
      </button>

      <button onClick={() => setProgress(Math.max(progress - 10, 0))}>
        Decrease
      </button>
    </div>
  );
}

export default App;