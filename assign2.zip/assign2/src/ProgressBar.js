import React from "react";

const ProgressBar = ({ progress }) => {
  return (
    <div style={{ width: "100%", backgroundColor: "#ddd" }}>
      <div
        style={{
          width: progress + "%",
          backgroundColor: "green",
          color: "white",
          textAlign: "center"
        }}
      >
        {progress}%
      </div>
    </div>
  );
};

export default ProgressBar;