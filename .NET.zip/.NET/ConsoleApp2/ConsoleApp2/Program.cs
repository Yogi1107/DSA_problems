﻿//// Interchanging the last and the first charscter of the string

//internal class Program
//{
//    private static void Main(string[] args)
//    {
//        Console.WriteLine("Enter a string:- ");
//        string str = Console.ReadLine();

//        //Console.WriteLine(str[0]);
//        char[] chars = str.ToCharArray();
//        int len = chars.Length;
//        char temp = chars[0];
//        chars[0] = chars[len - 1];
//        chars[len - 1] = temp;

//        string result = new string(chars);
//        Console.WriteLine(result);
//    }
//}





//// Accept n digits return the sum of the digits of that number

//internal class Program
//{
//    private static void Main(string[] args)
//    {
//        Console.WriteLine("Enter the number of digits ");
//        int n = Convert.ToInt32(Console.ReadLine());
//        int[] num = new int[n];
//        Console.WriteLine("Enter the elements:- ");
//        for (int i = 0; i < n; i++)
//        {
//            num[i] = Convert.ToInt32(Console.ReadLine());
//        }
//        Console.WriteLine(num.ToArray);
//        int sum = 0;
//        for (int i = 0; i < n; i++)
//        {
//            sum += num[i];
//        }
//        Console.WriteLine("Sum:- ", sum);
//    }
//}





//// Palindrome of a number 

//internal class Progranm
//{
//    private static void Main(string[] args)
//    {
//        Console.WriteLine("Enter a string:- ");
//        string num = Console.ReadLine();
//        int[] result = new int[num.Length];
//        int x = 0;
//        for (int i = num.Length; i >= 0; i--)
//        {
//            result[x++] = num[i];
//        }
//        Console.WriteLine(result);
//    }
//}





//// Square root of the number
//namespace ConsoleApp2;
//using System;

//public class Program
//{
//    public static void Main(String[] args)
//    {
//        Console.WriteLine("Enter a number:- ");
//        double squareRoot = Convert.ToDouble(Console.ReadLine());

//        double number = Math.Sqrt(squareRoot);
//        Console.WriteLine("The square root of the "+squareRoot+" is "+number);
//    }
//}





// Accepts seconds and returns that in min and sec

//internal class Program
//{
//    private static void Main(String[] args)
//    {
//        Console.WriteLine("Enter the time in seconds");
//        int seconds = Convert.ToInt32(Console.ReadLine());
//        Console.WriteLine(seconds);
//        int hours = 0;
//        int minutes = 0;
//        int seconds2 = 0;
//        while (seconds > 0)
//        {
//            if(seconds  % 3600 == 0){
//                hours += 1;
//                seconds -= 3600;
//            }
//            else if (seconds2 % 60 == 0)
//            {
//                minutes += 1;
//                seconds -= 60;
//            }
//            else
//            {
//                seconds2 = seconds;
//            }
//        }
//        Console.WriteLine("Hours: ",hours);
//        Console.WriteLine("Minutes: ", minutes);
//        Console.WriteLine("Seconds: ", seconds2);
//    }
//}





////Reverse a number 

//Console.WriteLine("Enter a number: ");
//int number = Convert.ToInt32(Console.ReadLine());
//int n = number;
//int result = 0;
//while (n > 0)
//{
//    int digit = n % 10;
//    result = (result * 10) + digit;
//    n = n / 10;
//}
//Console.WriteLine("The reversed number is " + result);





//// Store Manager

//Console.WriteLine("Enter the number of items:- ");
//int items = Convert.ToInt32(Console.ReadLine());
//if(items < 10)
//{
//    Console.WriteLine("Your bill is 120/-.");
//} else if (items >= 10 && items <= 99)
//{
//    Console.WriteLine("Your bill is 100/-.");
//}else
//{
//    Console.WriteLine("Your bill is 70/-.");
//}





// Convert the last 3 characters of the string to uppercase or convert entire string to upper case if len(String) > 3

//Console.WriteLine("Enter the string:- ");
//string str = Console.ReadLine();
//int len = str.Length;
//char[] strArray = str.ToCharArray();
//char[] charArray = new char[len];

//for (int i = 0; i < len - 3; i++)
//{
//    charArray[i] = strArray[i]; 
//}

//for (int i = len - 3; i < len; i++)
//{
//    charArray[i] = char.ToUpper(strArray[i]); 
//}

//string str2 = new string(charArray);
//Console.WriteLine(str2);





//Check the number is in array or not

//int[] arr = [23, 45, 67, 78, 8];
//Console.WriteLine("Enter the target to be find:- ");
//int target = Convert.ToInt32(Console.ReadLine());
//for (int i = 0; i < arr.Length; i++)
//{
//    if (arr[i] == target)
//    {
//        Console.WriteLine("Index of the target in array is" + i);
//    }
//    else
//    {
//        Console.WriteLine("Element not present in the array...");
//    }
//}





// Remove duplicates and concatenate the string

//using System;
//using System.Text;

//class Program
//{
//    static void Main()
//    {
//        Console.WriteLine("Enter first string: ");
//        string str1 = Console.ReadLine();

//        Console.WriteLine("Enter second string: ");
//        string str2 = Console.ReadLine();

//        // Concatenate the two strings
//        string combined = str1 + str2;

//        // Use a StringBuilder to build the result without duplicates
//        StringBuilder result = new StringBuilder();
//        foreach (char c in combined)
//        {
//            if (!result.ToString().Contains(c))
//            {
//                result.Append(c);
//            }
//        }

//        Console.WriteLine("Concatenated string without duplicates: " + result.ToString());
//    }
//}

