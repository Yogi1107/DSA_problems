﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;

public delegate int Operation(int x, int y);
public delegate bool NumberCheck(int number);
public delegate int PersonComparison(Person p1, Person p2);
public delegate void NotificationHandler(string message);

public class Program
{
    public static void PerformOperations(int x, int y, Operation op)
    {
        int result = op(x, y);
        Console.WriteLine($"Result: {result}");
    }

    public static bool IsEven(int num)
    {
        return num % 2 == 0;
    }

    public static int Add(int x, int y) => x + y;
    public static int Subtract(int x, int y) => x - y;

    public static int Operations(int x, int y, string operation)
    {
        if(operation == "Add"){
            Func<int,int,int> add = (x,y) => x + y;
            return add(x,y);
        }
        if(operation == "Subtract"){
            Func<int,int,int> subtract = (x,y) => x - y;
            return subtract(x,y);
        }
        if(operation == "Multiply"){
            Func<int,int,int> multiply= (x,y) => x * y;
            return multiply(x,y);
        }

        return -1;
    }

    static void Main()
    {
        // 1. PerformOperations
        Console.WriteLine("Enter two numbers");
        Console.Write("Enter the 1st number: ");
        int num1 = Convert.ToInt32(Console.ReadLine());

        Console.Write("Enter the 2nd number: ");
        int num2 = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("\nUsing named methods:");
        PerformOperations(num1, num2, Add);
        PerformOperations(num1, num2, Subtract);

        Console.WriteLine();



        // 2. Even delegate
        NumberCheck checkEven = IsEven;
        Console.Write("Enter a number to check even: ");
        int number = Convert.ToInt32(Console.ReadLine());

        bool result = checkEven(number);
        Console.WriteLine($"{number} is even: {result}");

        Console.WriteLine();



        // 3. Person List
        List<Person> people = new List<Person>
        {
            new Person("Alice", 30),
            new Person("Bob", 25),
            new Person("Charlie", 35),
            new Person("Alice", 22)
        };

        Console.WriteLine("Original List:");
        foreach (var p in people)
            Console.WriteLine(p);

        // Sort by Name
        PersonComparison compareByName = delegate (Person p1, Person p2)
        {
            return string.Compare(p1.Name, p2.Name, StringComparison.OrdinalIgnoreCase);
        };

        people.Sort(new Comparison<Person>(compareByName));

        Console.WriteLine("\nSorted by Name:");
        foreach (var p in people)
            Console.WriteLine(p);

        // Sort by Age
        PersonComparison compareByAge = delegate (Person p1, Person p2)
        {
            return p1.Age.CompareTo(p2.Age);
        };

        people.Sort(new Comparison<Person>(compareByAge));

        Console.WriteLine("\nSorted by Age:");
        foreach (var p in people)
            Console.WriteLine(p);

        Console.WriteLine();



        //4. Notification System
        Logger myLogger = new Logger();

        NotificationHandler handler = myLogger.LogTOConsole;
        handler += myLogger.LogtoFile;

        handler("Task Completed Successfully!");
        Console.WriteLine();



        //5. lambda expressions
        //a. accept string and find its length\
        Console.Write("Enter the Line:");
        string s = Console.ReadLine();

        Func<string, int> getLength = str => str.Length;

        int length = getLength(s);
        Console.WriteLine($"Length of the entered string: {length}");

        //b.Converts a string to uppercase
        Func<string, string> toupper = str => str.ToUpper();

        string upper_str = toupper(s);
        Console.WriteLine($"The string into upper case is: {upper_str}");

        //c. Add two integers
        Console.Write("Enter number 1: ");
        int a = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter number 2: ");
        int b = Convert.ToInt32(Console.ReadLine());

        Func<int, int, int> add = (a, b) => a + b;

        int add_number = add(a, b);
        Console.WriteLine($"The addition of two numbers {a} and {b} is: {add_number}");

        //d. filter even numbers from a list
        List<int> l = new List<int>()
        {
            1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24
        };
        var even_numbers = l.FindAll(x=>x%2==0);
        Console.WriteLine($"Even Numbers:");
        foreach (var value in even_numbers)
            Console.Write($"{value} ");
        Console.WriteLine();


        //Write C# code to create a method that accepts two numbers and lambda representing an operation (add, subtract, multiply)
        Console.Write("Enter a number: ");
        int x = Convert.ToInt32(Console.ReadLine());
        Console.Write("Enter a number: ");
        int y = Convert.ToInt32(Console.ReadLine());
        int result_Add = Operations(x, y, "Add");
        Console.WriteLine($"Addition of the two number {x} and {y} is {result_Add}.");
        int result_Subtract = Operations(x, y, "Subtract");
        Console.WriteLine($"Subtraction of the two number {x} and {y} is {result_Subtract}.");
        int result_Multiply = Operations(x, y, "Multiply");
        Console.WriteLine($"Multiplication of the two number {x} and {y} is {result_Multiply}.");
    }
}

public class Person
{
    public string Name { get; set; }
    public int Age { get; set; }

    public Person(string name, int age)
    {
        Name = name;
        Age = age;
    }

    public override string ToString()
    {
        return $"Name: {Name}, Age: {Age}";
    }
}

public class Logger
{
    public void LogTOConsole(string msg)
    {
        Console.WriteLine($"[Console Log]: {msg}");
    }
    public void LogtoFile(string msg)
    {
        string fileName = "Log.txt";
        File.AppendAllText(fileName, msg);
        Console.WriteLine($"[File Logged]: Message saved successfully!");
    }
}
