﻿using System;
using System.IO;

class Program
{
    static void Main()
    {
        //1. Copy data and disply both files
        File.Copy("data.txt", "copy.txt", true);

        using (StreamReader reader = new StreamReader("data.txt"))
        {
            string content = reader.ReadToEnd();
            Console.WriteLine("File Content:");
            Console.WriteLine(content);
        }

        using (StreamReader reader = new StreamReader("copy.txt"))
        {
            string content = reader.ReadToEnd();
            Console.WriteLine("File Content:");
            Console.WriteLine(content);
        }


        //2. Count number of lines, words and letters
        using (StreamReader reader = new StreamReader("data.txt"))
        {
            string filename = "data.txt";
            int line_count = 0;
            int word_count = 0;
            int letter_count = 0;
            foreach (string line in File.ReadLines(filename))
            {
                line_count++;

                letter_count += line.Count(char.IsLetter);

                word_count += line.Split(new[] { ' ', '\t' }, StringSplitOptions.RemoveEmptyEntries).Length;
            }
            Console.WriteLine($"Number of lines: {line_count}");
            Console.WriteLine($"Number of words: {letter_count}");
            Console.WriteLine($"Number of letter: {word_count}");
        }


        //3. Student Record Management System
        Console.WriteLine("*** Student Record Management System ***");
        Console.WriteLine("1. Add student (id, name, marks)");
        Console.WriteLine("2. View All students");
        Console.WriteLine("3. Search student by Id");
        Console.WriteLine("4. Delete Student Record");
        Console.WriteLine("5. EXIT");
        Console.Write("Enter your choice: ");
        int choice = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("*** Student Record Management System ***");
        while (choice != 5)
        {
            Console.WriteLine("\n1. Add student (id, name, marks)");
            Console.WriteLine("2. View All students");
            Console.WriteLine("3. Search student by Id");
            Console.WriteLine("4. Delete Student Record");
            Console.WriteLine("5. EXIT");
            Console.Write("Enter your choice: ");

            choice = Convert.ToInt32(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    AddStudent();
                    break;

                case 2:
                    ViewStudents();
                    break;

                case 3:
                    SearchStudent();
                    break;

                case 4:
                    DeleteStudent();
                    break;

                case 5:
                    Console.WriteLine("Exiting...");
                    break;

                default:
                    Console.WriteLine("Invalid choice!");
                    break;
            }
            static void AddStudent()
            {
                Console.Write("Enter the ID: ");
                string id = Console.ReadLine();

                Console.Write("Enter the Name: ");
                string name = Console.ReadLine();

                Console.Write("Enter the Marks: ");
                string marks = Console.ReadLine();

                using (StreamWriter writer = new StreamWriter("record.txt", true)) // append mode
                {
                    writer.WriteLine($"{id},{name},{marks}");
                }

                Console.WriteLine("Student added successfully!");
            }

            static void ViewStudents()
            {
                if (File.Exists("record.txt"))
                {
                    string[] lines = File.ReadAllLines("record.txt");
                    Console.WriteLine("\nStudent Records:");
                    foreach (string line in lines)
                    {
                        Console.WriteLine(line);
                    }
                }
                else
                {
                    Console.WriteLine("No records found.");
                }
            }

            static void SearchStudent()
            {
                Console.Write("Enter ID to search: ");
                string searchId = Console.ReadLine();

                if (File.Exists("record.txt"))
                {
                    var lines = File.ReadAllLines("record.txt");
                    var student = lines.FirstOrDefault(l => l.StartsWith(searchId + ","));

                    if (student != null)
                        Console.WriteLine("Student Found: " + student);
                    else
                        Console.WriteLine("Student not found.");
                }
            }

            static void DeleteStudent()
            {
                Console.Write("Enter ID to delete: ");
                string deleteId = Console.ReadLine();

                if (File.Exists("record.txt"))
                {
                    var lines = File.ReadAllLines("record.txt").ToList();
                    var student = lines.FirstOrDefault(l => l.StartsWith(deleteId + ","));

                    if (student != null)
                    {
                        lines.Remove(student);
                        File.WriteAllLines("record.txt", lines);
                        Console.WriteLine("Student deleted successfully!");
                    }
                    else
                    {
                        Console.WriteLine("Student not found.");
                    }
                }
            }
        }



        //4. Encrypt and decrypt the file content








        //5. Store Employee records in a file and search by ID.
        Console.WriteLine("Enter the number of employees: ");
        int count = Convert.ToInt32(Console.ReadLine());

        for (int i = 0; i < count; i++)
        {
            AddEmployee();
        }

        searchEmployee();

        static void AddEmployee()
        {
            Console.Write("Enter the ID: ");
            string id = Console.ReadLine();

            Console.Write("Enter the Name: ");
            string name = Console.ReadLine();


            using (StreamWriter writer = new StreamWriter("employee_record.txt", true)) // append mode
            {
                writer.WriteLine($"{id},{name}");
            }

            Console.WriteLine("Employee added successfully!");
        }

        static void searchEmployee()
        {
            Console.Write("Enter ID to search: ");
            string searchId = Console.ReadLine();

            if (File.Exists("employee_record.txt"))
            {
                var lines = File.ReadAllLines("employee_record.txt");
                var student = lines.FirstOrDefault(l => l.StartsWith(searchId + ","));

                if (student != null)
                    Console.WriteLine("Employee Found: " + student);
                else
                    Console.WriteLine("Employee not found.");
            }
        }
    }
}