﻿using System;
using System.Collections.Generic;
using System.Text;

class Employee
{
    public string Name;
    public float salary;

    public Employee(string Name, float salary)
    {
        this.Name = Name;
        this.salary = salary;
    }

}

class Process
{
    public string Name { get; set; }
    public int BurstTime { get; set; }
    public int WaitingTime { get; set; }
    public int TurnaroundTime { get; set; }
}


namespace ConsoleApp5
{
    internal class Program1
    {
    }
}
