﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Runtime.ExceptionServices;
using System.Text;

class Program
{
    public static void Main(String[] args)
    {
        // Program 1: To create an array of integers and display its sum, average, maximum and minimum
        //int[] intArray = { 1, 2, 3, 4, 5, 6, 7 };
        //int sum = 0;

        //int max = 0;
        //int min = int.MaxValue;

        //for (int i = 0; i < intArray.Length; i++)
        //{
        //    sum += intArray[i];
        //}

        //int average = sum / intArray.Length;

        //for (int i = 0; i < intArray.Length; i++)
        //{
        //    if (intArray[i] > max)
        //    {
        //        max = intArray[i];
        //    }
        //}

        //for (int i = 0; i < intArray.Length; i++)
        //{
        //    if (intArray[i] < min)
        //    {
        //        min = intArray[i];
        //    }
        //}

        //Console.WriteLine($"Sum of the numbers is: {sum}");
        //Console.WriteLine($"Average of the numbers is: {average}");
        //Console.WriteLine($"Maximum of the numbers is: {max}");
        //Console.WriteLine($"Minimum of the numbers is: {min}");
        //Console.WriteLine();





        // Program 2: To search for a given element in a List<int> and display its index if found
        //List<int> list = new List<int> { 1, 2, 3, 4, 5 };
        //for (int i = 0; i < list.Count; i++)
        //{
        //    Console.Write($"{list[i]} ");
        //}
        //Console.WriteLine("Enter the element to find:- ");
        //int key = Convert.ToInt32( Console.ReadLine() );
        //for (int i = 0; i < list.Count; i++)
        //{
        //    if (list[i] == key)
        //    {
        //        Console.WriteLine($"Element found at index {i+1}.");
        //        break;
        //    }
        //    else
        //    {
        //        continue;
        //    }
        //}
        //Console.WriteLine();




        //Program 3: TO sort and reverse elements in a List<string>
        //List<string> string_list = new List<string> { "Charlie", "Elon", "Blake", "Alice", "Doe"};
        //for (int i = 0;i < string_list.Count; i++)
        //{
        //    Console.WriteLine($"{string_list[i]}");
        //}
        //Console.WriteLine();
        //Console.WriteLine("Sorting the list");
        //string_list.Sort(System.StringComparer.OrdinalIgnoreCase);
        //for(int i = 0; i < string_list.Count; i++)
        //{
        //    Console.WriteLine($"{string_list[i]}");
        //}
        //Console.WriteLine();
        //Console.WriteLine("Reversing the list");
        //List<string> reversed_string_list = new List<string>();
        //for (int i = string_list.Count-1; i>=0; i--) 
        //{
        //    reversed_string_list.Add(string_list[i]);
        //}
        //for (int i = 0; i < reversed_string_list.Count; i++)
        //{
        //    Console.WriteLine($"{reversed_string_list[i]}");
        //}
        //Console.WriteLine();




        //Program 4: Write a program to count the number of even and odd elements in a List<int>
        //List<int> ints = new List<int>();
        //Console.Write("Enter the size of the array:- ");
        //int n = Convert.ToInt32(System.Console.ReadLine());
        //for (int i = 0; i < n; i++) { 
        //    Console.Write($"Enter the element {i}: ");
        //    int ele = Convert.ToInt32(System.Console.ReadLine());
        //    ints.Add(ele);
        //}
        //Console.WriteLine("Displaying the array:- ");
        //for (int i = 0; i < ints.Count; i++)
        //{
        //    Console.Write($"{ints[i]} ");
        //}
        //Console.WriteLine();
        //int even_count = 0;
        //int odd_count = 0;
        //for (int i = 0; i < ints.Count; i++)
        //{
        //    if (ints[i] % 2 == 0)
        //    {
        //        even_count++;
        //    }
        //    else
        //    {
        //        odd_count++;
        //    }
        //}
        //Console.WriteLine($"Even count : {even_count}");
        //Console.WriteLine($"Odd count : {odd_count}");
        //Console.WriteLine();





        //Program 5: To store student roll numbers and names using a Dictionary<int, string> and perform search, update and delete operations.
        //Dictionary<int, string> dic = new Dictionary<int, string>();
        //Console.Write("Enter the number of students:- ");
        //int n = Convert.ToInt32(System.Console.ReadLine());
        //for (int i = 0; i < n; i++)
        //{
        //    Console.WriteLine($"Enter the details of student {i + 1}:- ");
        //    Console.Write("Enter the roll no. :- ");
        //    int roll = Convert.ToInt32(System.Console.ReadLine());
        //    Console.Write("Enter the name:- ");
        //    string name = Convert.ToString(System.Console.ReadLine());
        //    dic[roll] = name;
        //}
        //foreach (int i in dic.Keys)
        //{
        //    Console.WriteLine($"{i}: {dic[i]}");
        //}
        //Console.WriteLine();
        //Console.WriteLine("*****MENU*****");
        //Console.WriteLine("1. Seraching the pair via key");
        //Console.WriteLine("2. Updating the pair via key");
        //Console.WriteLine("3. Removing the pair via key");
        //Console.WriteLine("4. Exit");
        //Console.WriteLine();
        //Console.Write("Enter your choice: ");
        //int choice = Convert.ToInt32(System.Console.ReadLine());
        //while (choice != 4)
        //{
        //    if (choice == 1)
        //    {
        //        Console.Write("Enter the key to be searched:- ");
        //        int key_roll = Convert.ToInt32(System.Console.ReadLine());
        //        foreach (int i in dic.Keys)
        //        {
        //            if (i == key_roll)
        //            {
        //                Console.WriteLine($"Pair present in Dictionary...");
        //                break;
        //            }
        //        }
        //        break;
        //    }
        //    else if (choice == 2)
        //    {
        //        Console.Write("Enter the key to be updated:- ");
        //        int key_roll = Convert.ToInt32(System.Console.ReadLine());
        //        Console.Write("Enter the value to be updated as:- ");
        //        string updated_value = Convert.ToString(System.Console.ReadLine());
        //        dic[key_roll] = updated_value;
        //        Console.WriteLine();
        //        foreach (int i in dic.Keys)
        //        {
        //            Console.WriteLine($"{i}: {dic[i]}");
        //        }
        //        Console.WriteLine();
        //        break;
        //    }
        //    else if (choice == 3)
        //    {
        //        Console.Write("Enter the key to be removed:- ");
        //        int key_roll = Convert.ToInt32(System.Console.ReadLine());
        //        dic.Remove(key_roll);
        //        foreach (int i in dic.Keys)
        //        {
        //            Console.WriteLine($"{i}: {dic[i]}");
        //        }
        //        break;
        //    }
        //}





        //Program 6: Write a progarm to reverse a string using a Stack<char>
        //Stack<char> char_Stack = new Stack<char>();
        //Console.Write("Enter the string: ");
        //string str = Console.ReadLine() ?? string.Empty; 
        //foreach (char c in str)
        //{
        //    char_Stack.Push(c);
        //}
        //StringBuilder rev_str = new StringBuilder();
        //while (char_Stack.Count > 0)
        //{
        //    rev_str.Append(char_Stack.Pop());
        //}
        //Console.WriteLine($"Reversed string: {rev_str}");





        //Program 7: Write a program to sort emplotee objects based on salary and name
        //Console.Write("Enter the number of employees: ");
        //if (!int.TryParse(Console.ReadLine(), out int n) || n <= 0)
        //{
        //    Console.WriteLine("Invalid number of employees.");
        //    return;
        //}

        //List<Employee> employees = new List<Employee>();
        //for (int i = 0; i < n; i++)
        //{
        //    Console.WriteLine($"\nEnter details for Employee {i + 1}:");
        //    Console.Write("Name: ");
        //    string name = Console.ReadLine();

        //    Console.Write("Salary: ");
        //    if (!decimal.TryParse(Console.ReadLine(), out decimal salary))
        //    {
        //        Console.WriteLine("Invalid salary. Skipping this employee.");
        //        continue;
        //    }
        //employees.Add(new Employee(name, (float)salary));
        //}

        //employees.Sort((p1, p2) =>
        //{
        //    int salaryCompare = p2.salary.CompareTo(p1.salary); 
        //    if (salaryCompare == 0)
        //    {
        //        return string.Compare(p1.Name, p2.Name, StringComparison.OrdinalIgnoreCase);
        //    }
        //    return salaryCompare;
        //});
        //employees.Sort((e1, e2) =>
        //     string.Compare(e1.Name, e2.Name, StringComparison.OrdinalIgnoreCase));

        //Console.WriteLine("\nEmployees sorted by Name (Ascending):");
        //foreach (var emp in employees)
        //{
        //    Console.WriteLine($"{emp.Name}, Salary: {emp.salary:C}");
        //}
        //employees.Sort((e1, e2) => e1.salary.CompareTo(e2.salary));

        //Console.WriteLine("\nEmployees sorted by Salary (descending):");
        //foreach (var emp in employees)
        //{
        //    Console.WriteLine($"{emp.Name}, Salary: {emp.salary:C}");
        //}





        //Program 8: Simulate a ticket booking system using a Queue<string>
        //Queue<string> bookingQueue = new Queue<string>();
        //int totalTickets = 5; 
        //bool exit = false;

        //while (!exit)
        //{
        //    Console.WriteLine("\n=== Ticket Booking System ===");
        //    Console.WriteLine("1. Book Ticket");
        //    Console.WriteLine("2. Process Booking");
        //    Console.WriteLine("3. View Waiting List");
        //    Console.WriteLine("4. Exit");
        //    Console.Write("Enter your choice: ");

        //    string choice = Console.ReadLine();

        //    switch (choice)
        //    {
        //        case "1":
        //            if (bookingQueue.Count < totalTickets)
        //            {
        //                Console.Write("Enter customer name: ");
        //                string name = Console.ReadLine()?.Trim();

        //                if (!string.IsNullOrEmpty(name))
        //                {
        //                    bookingQueue.Enqueue(name);
        //                    Console.WriteLine($"Ticket booked for {name}");
        //                }
        //                else
        //                {
        //                    Console.WriteLine(" Name cannot be empty.");
        //                }
        //            }
        //            else
        //            {
        //                Console.WriteLine("All tickets are booked. Please wait for cancellations.");
        //            }
        //            break;

        //        case "2":
        //            if (bookingQueue.Count > 0)
        //            {
        //                string processedCustomer = bookingQueue.Dequeue();
        //                Console.WriteLine($"Ticket issued to: {processedCustomer}");
        //            }
        //            else
        //            {
        //                Console.WriteLine("No bookings to process.");
        //            }
        //            break;

        //        case "3":
        //            if (bookingQueue.Count > 0)
        //            {
        //                Console.WriteLine("\nWaiting List:");
        //                foreach (var customer in bookingQueue)
        //                {
        //                    Console.WriteLine($"- {customer}");
        //                }
        //            }
        //            else
        //            {
        //                Console.WriteLine("No customers in the waiting list.");
        //            }
        //            break;

        //        case "4":
        //            exit = true;
        //            Console.WriteLine("Exiting Ticket Booking System...");
        //            break;

        //        default:
        //            Console.WriteLine("Invalid choice. Please try again.");
        //            break;
        //    }
        //}





        //Program 9: SJF scheduling in OS
            //try
            //{
            //    Console.Write("Enter number of processes: ");
            //    if (!int.TryParse(Console.ReadLine(), out int n) || n <= 0)
            //    {
            //        Console.WriteLine("❌ Invalid number of processes.");
            //        return;
            //    }

            //    List<Process> processes = new List<Process>();

            //    // Input process details
            //    for (int i = 0; i < n; i++)
            //    {
            //        Console.Write($"Enter name for process {i + 1}: ");
            //        string name = Console.ReadLine()?.Trim();
            //        if (string.IsNullOrEmpty(name))
            //        {
            //            Console.WriteLine("❌ Process name cannot be empty.");
            //            i--;
            //            continue;
            //        }

            //        Console.Write($"Enter burst time for {name}: ");
            //        if (!int.TryParse(Console.ReadLine(), out int burst) || burst <= 0)
            //        {
            //            Console.WriteLine("❌ Burst time must be a positive integer.");
            //            i--;
            //            continue;
            //        }

            //        processes.Add(new Process { Name = name, BurstTime = burst });
            //    }

            //    // Sort processes by burst time (SJF)
            //    processes = processes.OrderBy(p => p.BurstTime).ToList();

            //    // Calculate Waiting Time and Turnaround Time
            //    int totalWaitingTime = 0, totalTurnaroundTime = 0;
            //    processes[0].WaitingTime = 0;
            //    processes[0].TurnaroundTime = processes[0].BurstTime;

            //    for (int i = 1; i < n; i++)
            //    {
            //        processes[i].WaitingTime = processes[i - 1].WaitingTime + processes[i - 1].BurstTime;
            //        processes[i].TurnaroundTime = processes[i].WaitingTime + processes[i].BurstTime;
            //    }

            //    // Calculate totals
            //    totalWaitingTime = processes.Sum(p => p.WaitingTime);
            //    totalTurnaroundTime = processes.Sum(p => p.TurnaroundTime);

            //    // Display results
            //    Console.WriteLine("\n=== SJF Scheduling Result ===");
            //    Console.WriteLine("Process\tBurst\tWaiting\tTurnaround");
            //    foreach (var p in processes)
            //    {
            //        Console.WriteLine($"{p.Name}\t{p.BurstTime}\t{p.WaitingTime}\t{p.TurnaroundTime}");
            //    }

            //    Console.WriteLine($"\nAverage Waiting Time: {(float)totalWaitingTime / n:F2}");
            //    Console.WriteLine($"Average Turnaround Time: {(float)totalTurnaroundTime / n:F2}");
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine($"Error: {ex.Message}");
            //}

        // 10. Program for FIFO memory management
            
            
        }
    }