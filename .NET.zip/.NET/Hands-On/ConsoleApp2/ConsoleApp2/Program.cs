﻿using System;
using System.Collections;

namespace CollectionsDemo
{
    class Program
    {
        public static void Main(string[] args)
        {
            ArrayList arrayList = new ArrayList();
            arrayList.Add(5);
            arrayList.Add(4);
            arrayList.Add(3);
            arrayList.Add(1);
            arrayList.Add(2);
            for (int i = 0; i < arrayList.Count; i++)
            {
                Console.WriteLine($"{arrayList[i]}");
            }
            Console.WriteLine();
            arrayList.Sort();
            for (int i = 0; i < arrayList.Count; i++)
            {
                Console.WriteLine($"{arrayList[i]}");
            }
        }
    }
}