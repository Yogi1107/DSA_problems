﻿namespace ConsoleApp1
{

    // SINGLE - LEVEL INHERITENCE

    //public class Animal
    //{
    //    public Animal()
    //    {
    //        Console.WriteLine("Hey, from Parent");
    //    }
    //    public void method1()
    //    {
    //        Console.WriteLine("I am in Base Class.");
    //    }
    //    ~Animal()
    //    {
    //        Console.WriteLine("Parent Destroyed...");
    //    }
    //}

    //public class Dog : Animal
    //{
    //    public Dog()
    //    {
    //        Console.WriteLine("Hey, from Child");
    //    }
    //    public void method2()
    //    {
    //        Console.WriteLine("I am in Child class");
    //    }
    //    ~Dog()
    //    {
    //        Console.WriteLine("Child Destroyed");
    //    }
    //}

    //class Employee
    //{
    //    public string Name;
    //    public double Salary;

    //    public Employee(string name, double salary)
    //    {
    //        Name = name;
    //        Salary = salary;
    //    }

    //    public virtual void Display()
    //    {
    //        Console.WriteLine($"Name: {Name}, Salary: {Salary}");
    //    }
    //}


    //class Manager : Employee
    //{
    //    public string Dept_name;

    //    public Manager(string name, double salary, string dept_name) : base(name, salary)
    //    {
    //        Dept_name = dept_name;
    //    }

    //    public override void Display()
    //    {
    //        base.Display();
    //        Console.WriteLine($"Department:- {Dept_name}");
    //    }
    //}




    // MULTILEVEL INHERITENCE

    //class Vehicle
    //{
    //    public void Start() => Console.WriteLine("Vehicle Started");
    //}
    //class Car : Vehicle
    //{
    //    public void Horn() => Console.WriteLine("Car Horn: Beep!");
    //}
    //class ElectricCar : Car
    //{
    //    public void Charge() => Console.WriteLine("Charging Battery...");
    //}




    ////HIERARCHIAL INHERITENCE

    //class Animal
    //{
    //    public void Eats() => Console.WriteLine("Animal Eats...");
    //}
    //class Dog : Animal
    //{
    //    public void Barks() => Console.WriteLine("Dog Barks...");
    //}
    //class Cat: Animal
    //{
    //    public void Meow() => Console.WriteLine("Cat Meows...");
    //}

    //Abstract class 
    abstract class Appliance
    {
        public abstract void TurnOn();
    }
    class Fan : Appliance
    {
        public override void TurnOn() => Console.WriteLine("Fan On...");
    }
    class AC : Appliance
    {
        public override void TurnOn()
        {
            Console.WriteLine("AC On....");
        }
    }

    internal class Program
    {
        public static void Main(String[] args)
        {
            //Animal a = new Animal();
            //a.method1();
            //Dog dog = new Dog();
            //dog.method2();

            //Employee e1 = new Employee("John",25000);
            //e1.Display();
            //Manager m1 = new Manager("Blake", 50000, "IT Operations");
            //m1.Display();

            //Vehicle v1 = new Vehicle();
            //Car c1 = new Car();
            //ElectricCar ec1 = new ElectricCar();

            //v1.Start();
            //Console.WriteLine();
            //Console.WriteLine();
            //c1.Horn();
            //Console.WriteLine();
            //Console.WriteLine();
            //ec1.Start();
            //ec1.Horn();
            //ec1.Charge();

            //Dog d1 = new Dog();
            //Cat c1 = new Cat();
            //d1.Eats();
            //d1.Barks();
            //Console.WriteLine();
            //c1.Eats();
            //c1.Meow();

            Appliance a1 = new Fan();
            Appliance a2 = new AC();
            a1.TurnOn();
            a2.TurnOn();
        }
    }
}