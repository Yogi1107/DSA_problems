﻿using System;

class Book
{
    public string BookName;
    public string AuthorName;
    public int Price;

    public Book(string bookName, string author, int price)
    {
        BookName = bookName;
        AuthorName = author;
        Price = price;
    }

    public void Show()
    {
        Console.WriteLine($"{BookName} by {AuthorName}, Price: {Price}");
    }
}

class Library
{
    private Book[] books = new Book[0]; // start empty

    public void AddBook(string bookName, string author, int price)
    {
        Array.Resize(ref books, books.Length + 1);
        books[books.Length - 1] = new Book(bookName, author, price);
        Console.WriteLine($"{bookName} added!");
    }

    public void RemoveBook(string name)
    {
        int index = -1;
        for (int i = 0; i < books.Length; i++)
        {
            if (books[i].BookName == name)
            {
                index = i;
                break;
            }
        }

        if (index != -1)
        {
            for (int i = index; i < books.Length - 1; i++)
            {
                books[i] = books[i + 1];
            }
            Array.Resize(ref books, books.Length - 1);
            Console.WriteLine($"{name} removed!");
        }
        else
        {
            Console.WriteLine($"{name} not found.");
        }
    }

    public void ShowBooks()
    {
        if (books.Length == 0)
        {
            Console.WriteLine("Library is empty.");
        }
        else
        {
            for (int i = 0; i < books.Length; i++)
            {
                books[i].Show();
            }
        }
    }
}

namespace ConsoleApp3 { 
internal class Program5
{
}
}
