﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

class Time
{
    public int hours;
    public int minutes;
    public int seconds;

    public Time(int hours, int minutes, int seconds)
    {
        this.hours = hours;
        this.minutes = minutes;
        this.seconds = seconds;
    }

    public void addTimes(int start_hours, int start_minutes, int start_seconds, int end_hours, int end_minutes, int end_seconds)
    {
        int s = start_seconds + end_seconds;
        int m = start_minutes + end_minutes;
        int h = start_hours + end_hours;

        if (s >= 60)
        {
            m += s / 60;   
            s = s % 60;    
        }

        if (m >= 60)
        {
            h += m / 60;   
            m = m % 60;    
        }

        Console.WriteLine($"Adding two times we get {h:D2}:{m:D2}:{s:D2}");
    }

}

namespace ConsoleApp3
{
    internal class Program8
    {
    }
}
