﻿using System;
using System.Collections.Generic;
using System.Text;

class MobilePhone
{
    public string brand;
    public string model;
    public double price;
    public int batteryLife;

    public MobilePhone(string  brand, string model, double price, int batteryLife)
    {
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.batteryLife = batteryLife;
    }

    public void isAffordable(double budget)
    {
        if (price <= budget)
        {
            Console.WriteLine($"{model} of brand {brand} is affordable!");
        } else
        {
            Console.WriteLine($"{model} of brand {brand} is not affordable!");
        }
    }
}

namespace ConsoleApp3
{
    internal class Program9
    {
    }
}
