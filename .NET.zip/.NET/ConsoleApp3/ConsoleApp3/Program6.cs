﻿using System;
using System.Collections.Generic;
using System.Text;

class Employee
{
    public string name;
    public int id;
    public string designation;
    public double salary;

    public Employee(string name, int id, string designation, double salary)
    {
        this.name = name;
        this.id = id;
        this.designation = designation;
        this.salary = salary;
    }

    public void SalaryHike(int performance){
        double salary_hike = salary + (salary * performance / 100);
        Console.WriteLine($"{name}, your salary based on performance is: {salary_hike}.");
}
}


namespace ConsoleApp3
{
    internal class Program6
    {

    }
}
