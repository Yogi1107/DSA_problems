﻿using System;
using System.Collections.Generic;
using System.Text;

class Calculator
{
    public double number1;
    public double number2;

    public Calculator(double number1, double number2)
    {
        this.number1 = number1;
        this.number2 = number2;
    }

    public void add()
    {
        Console.WriteLine($"Addition of the 2 numbers is:- {number1 + number2}");
    }
    public void subtract()
    {
        if (number1 < number2)
        {
            Console.WriteLine($"Subtraction of the 2 numbers is:- {number2 - number1}");
        }
        else
        {
            Console.WriteLine($"Subtraction of the 2 numbers is:- {number1 - number2}");
        }
    }
    public void multiply()
    {
        Console.WriteLine($"Multiplication of the 2 numbers is:- {number1 * number2}");
    }
    public void divide()
    {
        if (number2 == 0)
        {
            Console.WriteLine("Cannot divide by zero...");
        }
        else
        {
            Console.WriteLine($"Division of the 2 numbers is:- {number1 / number2}");
        }
    }
}

namespace ConsoleApp3
{
    internal class Program10
    {
    }
}
