﻿class Planets
{
    string name;
    double distance_from_sun;
    double gravity_realtive;

    public Planets(string name, double distance_from_sun, double gravity_realtive)
    {
        this.name = name;
        this.distance_from_sun = distance_from_sun;
        this.gravity_realtive = gravity_realtive;
    }

    public void Show()
    {
        Console.WriteLine($"Name:- {name}, Distance from Sun:- {distance_from_sun}, Gravity Relative from Erath:- {gravity_realtive}");
    }
}

namespace ConsoleApp3
{
    public class Program2
    {
        public void Main(String[] args)
        {
            Planets Earth = new Planets("Earth", 10 ^ 5, 9.8);
            Planets Moon = new Planets("Moon", 10 ^ 8, 6.7);

        }
    }
}
