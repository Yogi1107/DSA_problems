﻿using System;
using System.Collections.Generic;
using System.Text;

class Airline_tickets
{
    string arrival_city;
    string destination_city;
    int flight_number;
    string seat_assignment;

    public Airline_tickets(string arrival_city, string destination_city, int flight_number, string seat_assignment)
    {
        this.arrival_city = arrival_city; 
        this.destination_city = destination_city;
        this.flight_number = flight_number;
        this.seat_assignment = seat_assignment;
    }

    public void Show()
    {
        Console.WriteLine($"Arrival City:- {arrival_city}, Destination City:- {destination_city}, Flight Number: {flight_number}, Seat Assignment:- {seat_assignment}");
    }
}

namespace ConsoleApp3
{
    internal class Program3
    {
    }
}
