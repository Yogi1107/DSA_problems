﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

class Polygon
{
    public int number_of_sides;
    public float length;

    public Polygon(int number_of_sides, float length){
        this.number_of_sides = number_of_sides;
        this.length = length;
    }

    public void Perimeter() {
        Console.WriteLine($"The perimeter of the polygon is {number_of_sides * length}.");
    }
    public void Area()
    {
        int l = Convert.ToInt32(length);
        float power = number_of_sides / 2;
        int p = Convert.ToInt32(power);
        Console.WriteLine($"The area of the polygon is {l^p}.");
    }
}

namespace ConsoleApp3
{
    internal class Program7
    {
    }
}
