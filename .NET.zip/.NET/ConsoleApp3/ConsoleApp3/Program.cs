﻿using System.Runtime.CompilerServices;
using ConsoleApp3;

class Bank
{
    long accountNo;
    string name;
    float balance;

    public Bank(long accountNo, string name, float balance)
    {
        this.accountNo = accountNo;
        this.name = name;
        this.balance = balance;
    }

    public void credit(float amount)
    {
        this.balance += amount;
        Console.WriteLine("Your total balance is: " + this.balance);
    }
    public void debit(float amount)
    {
        this.balance -= amount;
        if (this.balance < 500)
        {
            Console.WriteLine("Minimum Balnce to be kept must be 500");
            this.balance += amount;
        }
        Console.WriteLine("Your total balance is: " + this.balance);
    }
    public void checkBalance()
    {
        if (this.balance > 0)
        {
            Console.WriteLine("Your total balance is: " + this.balance);
        }
        else
        {
            Console.WriteLine("You have NIL Balanace");
        }
    }
}


class Program
{
    public static void Main(String[] args)
    {
        //1.
        //Banking Operations
        Bank c1 = new Bank(123456, "John", 12000);
        //Crediting the amount 
        c1.credit(100);
        //Debiting the amount
        c1.debit(11000);
        //Checking the Balance
        c1.checkBalance();


        //2.
        // Planetary Operations
        Planets p1 = new Planets("Earth", 10 ^ 5, 9.8);
        Console.WriteLine();
        p1.Show();
        Planets Moon = new Planets("Moon", 10 ^ 8, 6.7);
        Moon.Show();
        //Console.WriteLine(p1);


        //3.
        // Creating two Airline tickets
        Airline_tickets t1 = new Airline_tickets("Jaipur", "London", 23, "12F");
        Console.WriteLine();
        t1.Show();
        Airline_tickets t2 = new Airline_tickets("Berlin", "Delhi", 43, "42F");
        t2.Show();
        Console.WriteLine();

        //4.
        //Basic Operations on Complex NUmber
        ComplexNumber n1 = new ComplexNumber(2, 3);
        ComplexNumber n2 = new ComplexNumber(10, 20);
        n1.add(n1, n2);
        n1.subtract(n1, n2);
        n1.multiply(n1, n2);
        n2.display(n1, n2);
        Console.WriteLine();

        //5.
        //Library management
        Library lib = new Library();
        Console.WriteLine();
        lib.AddBook("1984", "George Orwell", 300);
        lib.AddBook("The Hobbit", "J.R.R. Tolkien", 500);
        Console.WriteLine("\nBooks in library:");
        lib.ShowBooks();
        lib.RemoveBook("1984");
        Console.WriteLine("\nBooks after removal:");
        lib.ShowBooks();
        Console.WriteLine();


        //6.
        //Employee management
        Employee e1 = new Employee("John",12,"Manager",60000);
        e1.SalaryHike(10);
        Console.WriteLine();


        //7.
        //Polygon Implementation
        Polygon poly1 = new Polygon(4, 4);
        poly1.Perimeter();
        poly1.Area();
        Console.WriteLine();


        //8,
        //Time implemetation
        Time time1 = new Time(1, 23, 45);
        time1.addTimes(1, 34, 56, 7, 34, 2);
        Console.WriteLine();


        //9.
        //MobilePhome class Implementation
        MobilePhone m1 = new MobilePhone("Redmi", "Note 12", 15000, 67);
        m1.isAffordable(14908);
        Console.WriteLine();


        //10.
        // Calculator class implementation
        Calculator cal1 = new Calculator(23, 0);
        cal1.add();
        cal1.subtract();
        cal1.multiply();
        cal1.divide();
    }
}