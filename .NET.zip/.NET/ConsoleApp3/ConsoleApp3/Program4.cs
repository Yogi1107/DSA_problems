﻿using System;
using System.Collections.Generic;
using System.Text;

class ComplexNumber
{
    public int real;
    public int imaginary;

    public ComplexNumber(int real, int imaginary)
    {
        this.real = real;
        this.imaginary = imaginary;
    }

    public void add(ComplexNumber n1, ComplexNumber n2)
    {
        int add_real = n1.real + n2.real;
        int add_img = n1.imaginary + n2.imaginary;
        Console.WriteLine($"The addition of the two complex number is {add_real} + {add_img}j");
    }
    public void subtract(ComplexNumber n1, ComplexNumber n2)
    {
        int sub_real = n1.real - n2.real;
        int sub_img = n1.imaginary - n2.imaginary;
        Console.WriteLine($"The subtraction of the two complex number is {sub_real} + {sub_img}j");
    }
    public void multiply(ComplexNumber n1, ComplexNumber n2)
    {
        int mul_real = n1.real * n2.real;
        int mul_img = n1.imaginary * n2.imaginary;
        Console.WriteLine($"The multiplication of the two complex number is {mul_real} + {mul_img}j");
    }
    public void display(ComplexNumber n1, ComplexNumber n2)
    {
        Console.WriteLine($"The two complex number are {n1.real} + {n1.imaginary}j and {n2.real} + {n2.imaginary}j");
    }
}

namespace ConsoleApp3
{
    internal class Program4
    {

    }
}
