﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

class Student
{
    public int Id;
    public string Name;

    public Student(int id, string Name)
    {
        this.Id = id;
        this.Name = Name;
    }
    public virtual void display()
    {
        Console.WriteLine($"Roll No. {Id}, Name: {Name}");
    }
}

class PGStudent : Student
{
    public string branch;
    public string semester;
    public PGStudent(int id, string Name, string branch, string semester) : base(id, Name)
    {
        this.branch = branch;
        this.semester = semester;
    }
    public override void display()
    {
        Console.WriteLine($"Roll No. {Id}, Name: {Name}, Branch: {branch}, Semester: {semester}.");
    }
}

namespace ConsoleApp4
{
    internal class Program2
    {
    }
}
