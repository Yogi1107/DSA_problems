﻿public class Program
{
    public static void Main(String[] Args)
    {
        // Class Vehicle 
        Vehicle v1 = new Vehicle("BMW", 2100000);
        Vehicle v2 = new Car("Audi", 2300000, 2025);
        v1.display();
        v2.display();

        // Class Student
        Console.WriteLine();
        Student student = new Student(12, "John");
        Student student1 = new PGStudent(23, "Blake","CS","Semester 1");
        student1.display();
        student.display();

        // Multilevel Inheritence 
        Console.WriteLine();
        Bird b1 = new Bird();
        b1.breathe();
        b1.walk();
        b1.fly();
        Console.WriteLine();

        //Hierarchial Inheritance
        SavingAccount sa = new SavingAccount("SA101", "Alice", 10000);
        sa.Deposit(2000);
        sa.InterestCalculation();

        Console.WriteLine();

        CurrentAccount ca = new CurrentAccount("CA201", "Bob", 5000);
        ca.Withdraw(1000);
        ca.OverdraftLimit();
        Console.WriteLine();

        //Library Management
        Book book = new Book("C# Programming", 14);
        Magazine magazine = new Magazine("Tech Weekly", 7);
        DVD dvd = new DVD("Inception", 2);

        book.DisplayInfo();
        magazine.DisplayInfo();
        dvd.DisplayInfo();
    }
}