﻿
class LibraryItem
{
    public string Title;
    public int BorrowedDays;

    public LibraryItem(string title, int borrowedDays)
    {
        Title = title;
        BorrowedDays = borrowedDays;
    }

    public void DisplayInfo()
    {
        Console.WriteLine($"Title: {Title}, Borrowed Days: {BorrowedDays}");
    }
}

class Book : LibraryItem
{
    public Book(string title, int borrowedDays)
        : base(title, borrowedDays)
    {
    }
}

class Magazine : LibraryItem
{
    public Magazine(string title, int borrowedDays)
        : base(title, borrowedDays)
    {
    }
}

class DVD : LibraryItem
{
    public DVD(string title, int borrowedDays)
        : base(title, borrowedDays)
    {
    }
}


namespace ConsoleApp4
{
    internal class Program5
    {
    }
}
