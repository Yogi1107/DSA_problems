﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.Marshalling;
using System.Text;

class Vehicle
{
    public string brand;
    public double price;
    
    public Vehicle(string brand, double price)
    {
        this.brand = brand;
        this.price = price;
    }
    public virtual void display(){
        Console.WriteLine($"Brand: {brand}, Price: {price}.");
    }
}

class Car : Vehicle
{
    public int year;
    public Car(string brand, double price, int year) : base(brand, price)
    {
        this.year = year;
    }
    public override void display(){
        Console.WriteLine($"Brand: {brand}, Price: {price}, Year: {year}.");
    }
}

namespace ConsoleApp4
{
    internal class Program1
    {
    }
}
