﻿using System;

class Account
{
    public string acc_no;
    public string name;
    public int balance;

    public Account(string acc_no, string name, int balance)
    {
        this.acc_no = acc_no;
        this.name = name;
        this.balance = balance;
    }

    public void Deposit(int amount)
    {
        balance += amount;
        Console.WriteLine($"Total balance is {balance}");
    }

    public void Withdraw(int amount)
    {
        balance -= amount;
        Console.WriteLine($"Total balance is {balance}");
    }
}

class SavingAccount : Account
{
    public SavingAccount(string acc_no, string name, int balance)
        : base(acc_no, name, balance)
    {
    }

    public void InterestCalculation()
    {
        int interest = balance * 5 / 100;
        balance += interest;
        Console.WriteLine($"Interest added. Total balance is {balance}");
    }
}

class CurrentAccount : Account
{
    public CurrentAccount(string acc_no, string name, int balance)
        : base(acc_no, name, balance)
    {
    }

    public void OverdraftLimit()
    {
        Console.WriteLine("Overdraft limit is 50,000");
    }
}

namespace ConsoleApp4
{
    internal class Program4
    {
    }
}
