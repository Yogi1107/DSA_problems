﻿using System;
using System.Collections.Generic;
using System.Text;

class LivingThing
{
    public void breathe()
    {
        Console.WriteLine("Living Beings Breathe...");
    }
}

class Animal : LivingThing
{
    public void walk()
    {
        Console.WriteLine("Animal can walk");
    }
}

class Bird : Animal
{
    public void fly()
    {
        Console.WriteLine("Birds fly...");
    }
}

namespace ConsoleApp4
{
    internal class Program3
    {
    }
}
