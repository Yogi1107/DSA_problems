﻿// Write a program to accept 3 numbers and find the largest one

//Console.WriteLine(("Enter a number 1: "));
//int a = Convert.ToInt32(Console.ReadLine());
//Console.WriteLine(("Enter a number 2: "));
//int b = Convert.ToInt32(Console.ReadLine());
//Console.WriteLine(("Enter a number 3: "));
//int c = Convert.ToInt32(Console.ReadLine());

//if (a > b && a > c){
//    Console.WriteLine(a + " is the greatest.");
//}
//else if(b > c)
//{
//    Console.WriteLine(b + " is the greatest.");
//}
//else
//{
//    Console.WriteLine(c + " is the greatest.");
//}



// Write a program to display Fiabonnaci Series till n

//Console.WriteLine("Enter a number: ");
//int n = Convert.ToInt32(Console.ReadLine());

//int first = 0;
//int second = 1;

//while (n > 0)
//{
//    Console.WriteLine(first + " ");
//    int next = first + second;
//    first = second;
//    second = next;
//    n -= 1;
//}



//// Write a Program to check whether given number is prime

//Console.WriteLine("Enter a number: ");
//int n = Convert.ToInt32(Console.ReadLine());

//bool is_Prime = true;
//for (int i=2; i<n; i++)
//{
//    if (n % i == 0)
//    {
//        is_Prime = false; 
//        break; 
//    }
//}
//if (is_Prime)
//{
//    Console.WriteLine(n + " is Prime Number");
//}
//else
//{
//    Console.WriteLine(n + " is not Prime Number");
//}



// Write a program to check whether the given number is an armstrong number

//using System.Globalization;

//Console.WriteLine("Enter a number: ");
//int number = Convert.ToInt32(Console.ReadLine());
//int n = number;
//double summ = 0;
//int length = number.ToString().Length;

//while (n > 0)
//{
//    double digit = n % 10;
//    summ += Math.Pow(digit, length);
//    n = n / 10;
//}
//if (number == summ)
//{
//    Console.WriteLine(number + " is a Armstrong Number.");
//}
//else
//{
//    Console.WriteLine(number + " is not a Armstrong Number.");
//}



////Write a program to reverse the digit

//Console.WriteLine("Enter a number: ");
//int number = Convert.ToInt32(Console.ReadLine());
//int n = number;
//int result = 0;
//while (n > 0)
//{
//    int digit = n % 10;
//    result = (result * 10) + digit;
//    n = n / 10;
//}
//Console.WriteLine("The reversed number is " + result);



// Write a Program to find a factorial of number

//Console.WriteLine("Enter a number: ");
//int number = Convert.ToInt32(Console.ReadLine());
//int n = number;
//int fact = 1;
//for  (int i = 1; i <= n; i++)
//{
//    fact *= i;
//}
//Console.WriteLine("Factorial of the number " + number + " is " + fact);



// Write a Program to check given number is palindrome of not

//Console.WriteLine("Enter a number:- ");
//int number = Convert.ToInt32(Console.ReadLine());
//int n = number;
//int reverse_num = 0;
//while (n > 0)
//{
//    int digit = n % 10;
//    reverse_num = (reverse_num * 10) + digit;
//    n = n / 10;
//}
//if (reverse_num == number)
//{
//    Console.WriteLine(number + " is a palindrome.");
//}
//else
//{
//    Console.WriteLine(number + " is not a palindrome.");
//}



// Write a Program to print factors of a number

//Console.WriteLine("Enter a number: ");
//int number = Convert.ToInt32(Console.ReadLine());
//Console.WriteLine("The Factors are:- ");
//for  (int i = 1; i <= number; i++)
//{
//    if (number % i == 0)
//    {
//        Console.Write(i+" ");
//    }
//}



// Write a Program to find GCD and LCM of two numbers
//static long gcd(long n1, long n2)
//{
//    if (n2 == 0)
//    {
//        return n1;
//    }
//    else
//    {
//        return gcd(n2, n1 % n2);
//    }
//}

//Console.WriteLine("Enter a number a: ");
//long number_a = Convert.ToInt64(Console.ReadLine());
//Console.WriteLine("Enter a number b: ");
//long number_b = Convert.ToInt64(Console.ReadLine());

//int hcf = (int)gcd(number_a, number_b);
//int lcm = (int)(number_a * number_b) / hcf;

//Console.WriteLine("The GCD of two numbers " + number_a + " and " + number_b + " is: " + hcf);
//Console.WriteLine("The LCM of two numbers " + number_a + " and " + number_b + " is: " + lcm);
